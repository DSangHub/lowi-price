# 🦉 LowisPice.com

**Price smarter. Always.**

LowisPice is a real-time price comparison app with a guaranteed-offer negotiation system, AI chat powered by Lowi (our price-savvy owl mascot), and Stripe card holds that make every offer credible.

---

## Features

- **Live prices** across top 10 e-commerce categories via SerpApi (Google Shopping)
- **Buy now / Buy soon / Worth waiting** AI verdicts based on real price history
- **Make an offer** — card held (not charged) until the seller accepts within 3 days
- **Auto-expiry** — unanswered offers release the hold automatically after 3 days
- **Lowi AI chat** — ask the owl anything about timing, deals, or whether to make an offer
- **Seller dashboard** — live countdown per offer, one-click accept/decline
- **Persistent SQLite** price history and offer storage (swap to Postgres when scaling)
- **JWT auth** with bcrypt passwords and rate-limited login endpoints

---

## Stack

| Layer | Tech |
|---|---|
| Frontend | React (JSX), Tailwind, Lucide icons |
| Backend | Node.js / Express |
| Database | SQLite via `better-sqlite3` |
| Payments | Stripe (manual-capture card holds) |
| Price data | SerpApi — Google Shopping |
| AI chat | Anthropic API (`claude-sonnet-4-6`) |
| Deployment | Vercel (frontend) + Render/Railway (backend) |

---

## Setup

### 1. Clone and install

```bash
git clone https://github.com/yourusername/lowispice.git
cd lowispice
npm install
```

### 2. Environment variables

```bash
cp .env.example .env
```

Fill in `.env`:

```
STRIPE_SECRET_KEY=sk_test_...
SERPAPI_KEY=...
JWT_SECRET=a-long-random-string
PORT=4000
```

### 3. Run the backend

```bash
npm start
```

Backend runs on `http://localhost:4000`. SQLite database auto-created as `price-compare.db`.

### 4. Run the frontend

The frontend (`price-compare-mvp.jsx`) is a React app. Drop it into a Vite or Create React App project, or deploy directly to Vercel.

Set `API_BASE` at the top of the file to your deployed backend URL.

---

## API reference

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/api/sellers/signup` | none | Create seller account |
| POST | `/api/sellers/login` | none | Get seller JWT |
| POST | `/api/buyers/signup` | none | Create buyer account |
| POST | `/api/buyers/login` | none | Get buyer JWT |
| GET | `/api/categories` | none | All 10 categories with live prices |
| GET | `/api/categories/:id` | none | Single category live prices |
| POST | `/api/offers` | buyer | Create offer record |
| POST | `/api/offers/:id/hold` | buyer | Authorize Stripe card hold — sends offer to seller |
| POST | `/api/offers/:id/cancel` | buyer | Release hold, cancel offer |
| GET | `/api/offers/:id` | buyer | Get offer status |
| POST | `/api/offers/:id/respond` | seller | Accept (capture) or decline (release) |
| GET | `/api/sellers/me/offers` | seller | List pending guaranteed offers |

---

## Deployment

### Backend → Render or Railway

1. Push this repo to GitHub
2. Create a new Web Service on [render.com](https://render.com) or [railway.app](https://railway.app)
3. Set build command: `npm install`
4. Set start command: `node server.js`
5. Add environment variables from `.env.example`
6. Enable persistent disk (for `price-compare.db`) — Render calls this a "Disk"

### Frontend → Vercel

1. Create a new Vercel project, import this repo
2. Set the root directory to your frontend folder
3. No build config needed if using the JSX directly with Vite
4. Update `API_BASE` in `price-compare-mvp.jsx` to your Render/Railway backend URL

### Stripe test mode

Use card number `4242 4242 4242 4242`, any future expiry, any CVC.

---

## Files

```
server.js               Express backend
db.js                   SQLite persistence layer (offers + price history)
price-compare-mvp.jsx   React frontend with Lowi mascot + AI chat
checkout.html           Stripe Payment Element card hold popup
seller-dashboard.html   Seller offer management dashboard
package.json
.env.example
.gitignore
README.md
```

---

## License

MIT
