/**
 * Price Comparison App — Backend MVP
 * ------------------------------------------------------------------
 * Implements:
 *  - Live price fetching (SerpApi / Google Shopping), persisted to SQLite
 *    so history survives restarts
 *  - Offer submission with required card hold (buyer -> seller)
 *  - Seller accept (auto-capture) / decline (auto-release)
 *  - 3-day response deadline with hourly auto-expiry sweep
 *  - Notification stubs (swap in Twilio/SendGrid/push later)
 *
 * SETUP:
 *   npm install
 *   cp .env.example .env   # fill in STRIPE_SECRET_KEY and SERPAPI_KEY
 *   node server.js
 *
 * Persistence: SQLite file `price-compare.db` via db.js (see that file for
 * the schema and how to swap in Postgres later without touching routes).
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const Stripe = require("stripe");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const store = require("./db");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_REPLACE_ME");
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

// 2. Refuse to boot with the placeholder secret outside local dev — a
// forgeable JWT secret means anyone can mint a valid buyer/seller token.
if (JWT_SECRET === "dev-secret-change-me" && process.env.NODE_ENV === "production") {
  console.error("FATAL: JWT_SECRET is unset/default while NODE_ENV=production. Set a long random JWT_SECRET in .env before deploying.");
  process.exit(1);
}

const app = express();
app.use(cors());
app.use(express.json());

// 1. Rate limit auth endpoints to slow down credential brute-forcing.
// Tune window/max for your real traffic; this errs strict for an MVP.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 10, // 10 attempts per IP per window per route
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Try again in a few minutes." },
});

// ---- Auth helpers ----
// Buyers and sellers each get a JWT after login, carrying { role, id }.
// role is "buyer" or "seller"; id is buyerId or sellerName respectively.
function signToken(role, id) {
  return jwt.sign({ role, id }, JWT_SECRET, { expiresIn: "7d" });
}

function requireAuth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "Missing Authorization bearer token" });
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (payload.role !== role) return res.status(403).json({ error: `Requires ${role} auth` });
      req.auth = payload;
      next();
    } catch (e) {
      return res.status(401).json({ error: "Invalid or expired token" });
    }
  };
}

// ---- Signup / login ----

app.post("/api/sellers/signup", authLimiter, async (req, res) => {
  const { sellerName, password } = req.body;
  if (!sellerName || !password) return res.status(400).json({ error: "sellerName and password required" });
  if (store.getSeller(sellerName)) return res.status(409).json({ error: "Seller already exists" });
  const hash = await bcrypt.hash(password, 10);
  store.createSeller(sellerName, hash);
  res.json({ token: signToken("seller", sellerName) });
});

app.post("/api/sellers/login", authLimiter, async (req, res) => {
  const { sellerName, password } = req.body;
  const seller = store.getSeller(sellerName || "");
  if (!seller || !(await bcrypt.compare(password || "", seller.passwordHash))) {
    return res.status(401).json({ error: "Invalid seller name or password" });
  }
  res.json({ token: signToken("seller", sellerName) });
});

app.post("/api/buyers/signup", authLimiter, async (req, res) => {
  const { buyerId, password } = req.body;
  if (!buyerId || !password) return res.status(400).json({ error: "buyerId and password required" });
  if (store.getBuyer(buyerId)) return res.status(409).json({ error: "Buyer already exists" });
  const hash = await bcrypt.hash(password, 10);
  store.createBuyer(buyerId, hash);
  res.json({ token: signToken("buyer", buyerId) });
});

app.post("/api/buyers/login", authLimiter, async (req, res) => {
  const { buyerId, password } = req.body;
  const buyer = store.getBuyer(buyerId || "");
  if (!buyer || !(await bcrypt.compare(password || "", buyer.passwordHash))) {
    return res.status(401).json({ error: "Invalid buyer id or password" });
  }
  res.json({ token: signToken("buyer", buyerId) });
});

// ---- Notification stubs ----
// Replace these with real Twilio SMS / SendGrid email / push notification calls.
function alertSeller(offer) {
  console.log(`[ALERT -> SELLER ${offer.sellerName}] New offer of $${offer.amount} on ${offer.categoryName}`);
  // e.g. await sgMail.send({ to: sellerEmail, subject: "New offer", ... })
}

function alertBuyer(offer, message) {
  console.log(`[ALERT -> BUYER ${offer.buyerId}] ${message}`);
  // e.g. await twilioClient.messages.create({ to: buyerPhone, body: message })
}

// ---- Live price data via SerpApi (Google Shopping) ----
// Get a key at https://serpapi.com — free tier covers light testing.
const SERPAPI_KEY = process.env.SERPAPI_KEY || "";

// Search query used per category. Tune these to match the exact product
// tier you want comparable prices for.
const CATEGORY_CONFIG = [
  { id: "phone", name: "Smartphones", query: "iPhone 16" },
  { id: "laptop", name: "Laptops", query: "14 inch laptop" },
  { id: "headphones", name: "Headphones", query: "wireless noise cancelling headphones" },
  { id: "sneakers", name: "Sneakers", query: "running shoes" },
  { id: "vacuum", name: "Robot Vacuums", query: "robot vacuum self empty" },
  { id: "tv", name: "TVs", query: "55 inch 4K TV" },
  { id: "blender", name: "Blenders", query: "high power blender" },
  { id: "mattress", name: "Mattresses", query: "queen memory foam mattress" },
  { id: "backpack", name: "Backpacks", query: "laptop backpack" },
  { id: "coffeemaker", name: "Coffee Makers", query: "drip coffee maker grinder" },
];

// In-memory cache just to avoid hammering SerpApi on every request — the
// actual history now lives in SQLite (price_snapshots table) and survives
// restarts. This cache only governs "how often do we call SerpApi."
const fetchCache = new Map(); // categoryId -> lastFetchedAt (ms)
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 min — keeps SerpApi usage/cost down

async function fetchLivePrices(categoryId) {
  const cfg = CATEGORY_CONFIG.find((c) => c.id === categoryId);
  if (!cfg) throw new Error("Unknown category");

  const lastFetchedAt = fetchCache.get(categoryId);
  const isFresh = lastFetchedAt && Date.now() - lastFetchedAt < CACHE_TTL_MS;

  if (!isFresh) {
    if (!SERPAPI_KEY) {
      // No key configured — fall back to whatever's already in SQLite
      // (if anything) rather than hard-failing every request.
      const existingHistory = store.getPriceHistory(categoryId);
      const existingRetailers = store.getLatestRetailers(categoryId);
      if (existingHistory.length) {
        return { categoryId, name: cfg.name, retailers: existingRetailers, history: existingHistory };
      }
      throw new Error("SERPAPI_KEY not set — add it to .env to fetch live prices");
    }

    const url = `https://serpapi.com/search.json?engine=google_shopping&q=${encodeURIComponent(
      cfg.query
    )}&api_key=${SERPAPI_KEY}`;

    const res = await fetch(url);
    const data = await res.json();
    if (data.error) throw new Error(data.error);

    const results = (data.shopping_results || []).slice(0, 6).map((r) => ({
      name: r.source || "Retailer",
      price: typeof r.extracted_price === "number" ? r.extracted_price : null,
      shipping: 0, // SerpApi doesn't reliably break out shipping; treat as included
      link: r.link,
    })).filter((r) => r.price != null);

    if (results.length) {
      const bestPrice = Math.min(...results.map((r) => r.price));
      store.appendPriceSnapshot(categoryId, bestPrice, results);
    }
    fetchCache.set(categoryId, Date.now());
  }

  const history = store.getPriceHistory(categoryId);
  const retailers = store.getLatestRetailers(categoryId);
  return { categoryId, name: cfg.name, retailers, history };
}

// GET all categories with their latest persisted/live prices.
app.get("/api/categories", async (req, res) => {
  try {
    const all = await Promise.all(CATEGORY_CONFIG.map((c) => fetchLivePrices(c.id)));
    res.json({ categories: all });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

// GET a single category's prices (forces a refetch if cache is stale).
app.get("/api/categories/:id", async (req, res) => {
  try {
    const entry = await fetchLivePrices(req.params.id);
    res.json({ category: entry });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

// How long a seller has to respond once a hold is placed.
const RESPONSE_WINDOW_MS = 3 * 24 * 60 * 60 * 1000; // 3 days

// 1. Buyer creates an offer record (not yet sent to seller — needs a card hold first)
app.post("/api/offers", requireAuth("buyer"), (req, res) => {
  const { sellerName, categoryName, amount, listPrice } = req.body;
  const buyerId = req.auth.id; // trust the token, not the request body
  if (!sellerName || !amount) {
    return res.status(400).json({ error: "sellerName and amount are required" });
  }
  const offer = store.createOffer({ buyerId, sellerName, categoryName, amount, listPrice });
  res.json({ offer });
});

// 2. Buyer authorizes a card hold for the offer amount. Only once this
// succeeds does the offer actually get sent to the seller — this is what
// makes the offer "guaranteed" and gives the seller a real incentive to accept.
app.post("/api/offers/:id/hold", requireAuth("buyer"), async (req, res) => {
  const offer = store.getOffer(req.params.id);
  if (!offer) return res.status(404).json({ error: "Offer not found" });
  if (offer.buyerId !== req.auth.id) return res.status(403).json({ error: "Not your offer" });
  if (offer.status !== "awaiting_hold") {
    return res.status(400).json({ error: "This offer already has a hold or has been resolved" });
  }

  const { paymentMethodId, currency = "usd" } = req.body;
  if (!paymentMethodId) return res.status(400).json({ error: "paymentMethodId is required" });

  try {
    // capture_method: "manual" authorizes the funds without charging them yet.
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(offer.amount * 100), // cents
      currency,
      payment_method: paymentMethodId,
      capture_method: "manual",
      confirm: true,
      automatic_payment_methods: { enabled: true, allow_redirects: "never" },
    });

    const expiresAt = new Date(Date.now() + RESPONSE_WINDOW_MS).toISOString();
    const updated = store.updateOffer(offer.id, {
      status: "pending_seller",
      paymentIntentId: paymentIntent.id,
      expiresAt,
    });

    alertSeller(updated);

    res.json({ offer: updated, paymentIntent: { id: paymentIntent.id, status: paymentIntent.status } });
  } catch (err) {
    console.error("Stripe hold failed:", err.message);
    res.status(402).json({ error: err.message });
  }
});

// 3. Seller responds. Accept -> capture the held funds immediately (charge
// goes through). Decline -> release the hold immediately (no charge).
app.post("/api/offers/:id/respond", requireAuth("seller"), async (req, res) => {
  const offer = store.getOffer(req.params.id);
  if (!offer) return res.status(404).json({ error: "Offer not found" });
  if (offer.sellerName !== req.auth.id) return res.status(403).json({ error: "Not your offer to respond to" });
  if (offer.status !== "pending_seller") {
    return res.status(400).json({ error: "Offer is not awaiting a seller response" });
  }
  if (!offer.paymentIntentId) {
    return res.status(400).json({ error: "Offer has no active hold to act on" });
  }
  if (offer.expiresAt && Date.now() > new Date(offer.expiresAt).getTime()) {
    return res.status(400).json({ error: "Response window has expired — this offer was auto-released" });
  }

  const { accept } = req.body; // boolean

  try {
    if (accept) {
      const captured = await stripe.paymentIntents.capture(offer.paymentIntentId);
      const updated = store.updateOffer(offer.id, { status: "accepted" });
      alertBuyer(updated, `Your offer of $${offer.amount} was accepted — your card was charged. Order confirmed.`);
      return res.json({ offer: updated, paymentIntent: { id: captured.id, status: captured.status } });
    } else {
      const cancelled = await stripe.paymentIntents.cancel(offer.paymentIntentId);
      const updated = store.updateOffer(offer.id, { status: "declined" });
      alertBuyer(updated, `Your offer of $${offer.amount} was declined. Your card hold was released — no charge made.`);
      return res.json({ offer: updated, paymentIntent: { id: cancelled.id, status: cancelled.status } });
    }
  } catch (err) {
    console.error("Stripe respond failed:", err.message);
    res.status(402).json({ error: err.message });
  }
});

// 4. Fetch a single offer (for polling status from the frontend)
app.get("/api/offers/:id", requireAuth("buyer"), (req, res) => {
  const offer = store.getOffer(req.params.id);
  if (!offer) return res.status(404).json({ error: "Offer not found" });
  if (offer.buyerId !== req.auth.id) return res.status(403).json({ error: "Not your offer" });
  res.json({ offer });
});

// 5. Buyer cancels their own pending offer (releases the hold, no charge)
app.post("/api/offers/:id/cancel", requireAuth("buyer"), async (req, res) => {
  const offer = store.getOffer(req.params.id);
  if (!offer) return res.status(404).json({ error: "Offer not found" });
  if (offer.buyerId !== req.auth.id) return res.status(403).json({ error: "Not your offer" });
  if (offer.status !== "pending_seller") {
    return res.status(400).json({ error: "Only a pending offer can be cancelled" });
  }

  try {
    if (offer.paymentIntentId) {
      await stripe.paymentIntents.cancel(offer.paymentIntentId);
    }
    const updated = store.updateOffer(offer.id, { status: "cancelled" });
    alertBuyer(updated, `You cancelled your offer of $${offer.amount}. Your card hold was released.`);
    res.json({ offer: updated });
  } catch (err) {
    res.status(402).json({ error: err.message });
  }
});

// 6. List pending (guaranteed) offers for the authenticated seller.
app.get("/api/sellers/me/offers", requireAuth("seller"), (req, res) => {
  const offers = store.getPendingOffersBySeller(req.auth.id);
  res.json({ offers });
});

// ---- Background sweep: auto-release any hold whose 3-day response window
// has passed without the seller responding. ----
async function sweepExpiredOffers() {
  const expired = store.getExpiredPendingOffers();
  for (const offer of expired) {
    try {
      if (offer.paymentIntentId) {
        await stripe.paymentIntents.cancel(offer.paymentIntentId);
      }
      store.updateOffer(offer.id, { status: "expired" });
      alertBuyer(offer, `Your offer of $${offer.amount} expired after 3 days with no response. Your card hold was released.`);
      console.log(`[ALERT -> SELLER ${offer.sellerName}] Offer #${offer.id} expired unanswered.`);
    } catch (err) {
      console.error(`Failed to auto-release expired offer ${offer.id}:`, err.message);
    }
  }
}
setInterval(sweepExpiredOffers, 60 * 60 * 1000); // check hourly; tune as needed

const PORT = process.env.PORT || 4000;
if (JWT_SECRET === "dev-secret-change-me") {
  console.warn("WARNING: using the default JWT_SECRET. Fine for local dev, but set a real random value in .env before deploying anywhere reachable.");
}
app.listen(PORT, () => console.log(`Price comparison backend running on :${PORT} (persisted to price-compare.db)`));
