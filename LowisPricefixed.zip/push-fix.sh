#!/usr/bin/env bash
# Pushes the fixed LowisPrice project to GitHub.
# 1. Put this script in the SAME folder as the unzipped LowisPrice-fixed project
#    (the folder that contains package.json, server.js, src/, etc.)
# 2. Run:  bash push-fix.sh
# You'll be asked for your GitHub username and a token (paste token as the password).
set -e
git init -q
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/DSangHub/lowi-price.git
git add -A
git commit -q -m "Fix corrupted App.jsx and rename LowisPice -> LowisPrice"
git branch -M main
echo ">> Pushing to GitHub (force-overwrites the mangled main)..."
git push -f origin main
echo ">> Done. Vercel will redeploy automatically."
