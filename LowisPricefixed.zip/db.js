/**
 * Persistence layer — SQLite via better-sqlite3.
 * ------------------------------------------------------------------
 * Why SQLite for now: zero config, single file, no separate DB server
 * to run/manage. It comfortably handles this app's write volume (price
 * snapshots every ~30 min, offers created occasionally).
 *
 * To move to Postgres later: swap this file for a `pg` Pool, keep the
 * same exported function names (getOffer, createOffer, updateOffer,
 * appendPriceSnapshot, getPriceHistory, etc.) so server.js doesn't change.
 */

const Database = require("better-sqlite3");
const db = new Database("price-compare.db");

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS sellers (
    name TEXT PRIMARY KEY,
    passwordHash TEXT NOT NULL,
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS buyers (
    id TEXT PRIMARY KEY,
    passwordHash TEXT NOT NULL,
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS offers (
    id TEXT PRIMARY KEY,
    buyerId TEXT NOT NULL,
    sellerName TEXT NOT NULL,
    categoryName TEXT,
    amount REAL NOT NULL,
    listPrice REAL,
    status TEXT NOT NULL,
    paymentIntentId TEXT,
    createdAt TEXT NOT NULL,
    expiresAt TEXT
  );

  CREATE TABLE IF NOT EXISTS price_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    categoryId TEXT NOT NULL,
    bestPrice REAL NOT NULL,
    retailersJson TEXT NOT NULL,
    fetchedAt TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_snapshots_category ON price_snapshots(categoryId, fetchedAt);
  CREATE INDEX IF NOT EXISTS idx_offers_seller_status ON offers(sellerName, status);
`);

// ---- Sellers & buyers (basic auth accounts) ----

function createSeller(name, passwordHash) {
  db.prepare("INSERT INTO sellers (name, passwordHash, createdAt) VALUES (?, ?, ?)").run(
    name, passwordHash, new Date().toISOString()
  );
}

function getSeller(name) {
  return db.prepare("SELECT * FROM sellers WHERE name = ?").get(name) || null;
}

function createBuyer(id, passwordHash) {
  db.prepare("INSERT INTO buyers (id, passwordHash, createdAt) VALUES (?, ?, ?)").run(
    id, passwordHash, new Date().toISOString()
  );
}

function getBuyer(id) {
  return db.prepare("SELECT * FROM buyers WHERE id = ?").get(id) || null;
}

// ---- Offers ----

let nextOfferId = (db.prepare("SELECT MAX(CAST(id AS INTEGER)) AS maxId FROM offers").get().maxId || 0) + 1;

function createOffer({ buyerId, sellerName, categoryName, amount, listPrice }) {
  const id = String(nextOfferId++);
  const offer = {
    id,
    buyerId,
    sellerName,
    categoryName,
    amount,
    listPrice,
    status: "awaiting_hold",
    paymentIntentId: null,
    createdAt: new Date().toISOString(),
    expiresAt: null,
  };
  db.prepare(`
    INSERT INTO offers (id, buyerId, sellerName, categoryName, amount, listPrice, status, paymentIntentId, createdAt, expiresAt)
    VALUES (@id, @buyerId, @sellerName, @categoryName, @amount, @listPrice, @status, @paymentIntentId, @createdAt, @expiresAt)
  `).run(offer);
  return offer;
}

function getOffer(id) {
  return db.prepare("SELECT * FROM offers WHERE id = ?").get(id) || null;
}

function updateOffer(id, fields) {
  const current = getOffer(id);
  if (!current) return null;
  const updated = { ...current, ...fields };
  db.prepare(`
    UPDATE offers SET
      status = @status,
      paymentIntentId = @paymentIntentId,
      expiresAt = @expiresAt
    WHERE id = @id
  `).run(updated);
  return updated;
}

function getPendingOffersBySeller(sellerName) {
  return db.prepare(
    "SELECT * FROM offers WHERE sellerName = ? AND status = 'pending_seller' ORDER BY createdAt DESC"
  ).all(sellerName);
}

function getExpiredPendingOffers() {
  const now = new Date().toISOString();
  return db.prepare(
    "SELECT * FROM offers WHERE status = 'pending_seller' AND expiresAt IS NOT NULL AND expiresAt < ?"
  ).all(now);
}

// ---- Price history ----

function appendPriceSnapshot(categoryId, bestPrice, retailers) {
  db.prepare(`
    INSERT INTO price_snapshots (categoryId, bestPrice, retailersJson, fetchedAt)
    VALUES (?, ?, ?, ?)
  `).run(categoryId, bestPrice, JSON.stringify(retailers), new Date().toISOString());
}

// Returns the last `limit` best-price points for a category, oldest first —
// directly usable as the sparkline/history array on the frontend.
function getPriceHistory(categoryId, limit = 30) {
  const rows = db.prepare(
    "SELECT bestPrice FROM price_snapshots WHERE categoryId = ? ORDER BY fetchedAt DESC LIMIT ?"
  ).all(categoryId, limit);
  return rows.map((r) => r.bestPrice).reverse();
}

function getLatestRetailers(categoryId) {
  const row = db.prepare(
    "SELECT retailersJson FROM price_snapshots WHERE categoryId = ? ORDER BY fetchedAt DESC LIMIT 1"
  ).get(categoryId);
  return row ? JSON.parse(row.retailersJson) : [];
}

module.exports = {
  createSeller,
  getSeller,
  createBuyer,
  getBuyer,
  createOffer,
  getOffer,
  updateOffer,
  getPendingOffersBySeller,
  getExpiredPendingOffers,
  appendPriceSnapshot,
  getPriceHistory,
  getLatestRetailers,
};
